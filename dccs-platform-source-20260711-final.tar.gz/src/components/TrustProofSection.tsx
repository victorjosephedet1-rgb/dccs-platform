import React, { useState, useEffect } from 'react';
import { Shield, CheckCircle, Globe, Lock, Star, Quote } from 'lucide-react';
import { DCCSCodeDisplay } from './DCCSCodeDisplay';
import { supabase } from '../lib/supabase';

// ─── Live platform stats ───────────────────────────────────────────────────────

interface PlatformStats {
  total_uploads:  number;
  total_creators: number;
  total_codes:    number;
}

function usePlatformStats(): PlatformStats {
  const [stats, setStats] = useState<PlatformStats>({
    total_uploads:  0,
    total_creators: 0,
    total_codes:    0,
  });

  useEffect(() => {
    Promise.all([
      supabase.from('uploads').select('id', { count: 'exact', head: true }).eq('upload_status', 'completed'),
      supabase.from('profiles').select('id', { count: 'exact', head: true }),
      supabase.from('dccs_certificates').select('id', { count: 'exact', head: true }),
    ]).then(([uploads, profiles, certs]) => {
      setStats({
        total_uploads:  uploads.count ?? 0,
        total_creators: profiles.count ?? 0,
        total_codes:    certs.count ?? 0,
      });
    }).catch(() => {});
  }, []);

  return stats;
}

function formatCount(n: number): string {
  if (n >= 1000) return `${(n / 1000).toFixed(1)}k+`;
  return n > 0 ? `${n}+` : '0';
}

// ─── Testimonials ─────────────────────────────────────────────────────────────

const TESTIMONIALS = [
  {
    name:    'Adaeze O.',
    role:    'Music Producer',
    country: 'Nigeria',
    avatar:  'AO',
    color:   '#0ea5e9',
    quote:   'I uploaded 12 beats in one session. Every single one got a DCCS code instantly. This is what musicians in Africa have been waiting for.',
    stars:   5,
  },
  {
    name:    'Marcus L.',
    role:    'Filmmaker',
    country: 'United Kingdom',
    avatar:  'ML',
    color:   '#10b981',
    quote:   'Before DCCS I had no way to prove I shot a film first. Now I have timestamped proof for every scene file. Game changer.',
    stars:   5,
  },
  {
    name:    'Priya S.',
    role:    'Digital Artist',
    country: 'India',
    avatar:  'PS',
    color:   '#f59e0b',
    quote:   "My artwork was stolen three times. Since registering on DCCS I have a permanent record that's mine and nobody can dispute it.",
    stars:   5,
  },
];

function TestimonialCard({ t, active }: { t: typeof TESTIMONIALS[0]; active: boolean }) {
  return (
    <div
      className="rounded-2xl p-6 transition-all duration-500"
      style={{
        background:   active ? 'rgba(255,255,255,0.05)' : 'rgba(255,255,255,0.02)',
        border:       `1px solid ${active ? `${t.color}30` : 'rgba(255,255,255,0.06)'}`,
        transform:    active ? 'scale(1.01)' : 'scale(1)',
        opacity:      active ? 1 : 0.65,
      }}
    >
      {/* Stars */}
      <div className="flex gap-0.5 mb-4">
        {Array.from({ length: t.stars }).map((_, i) => (
          <Star key={i} className="w-3.5 h-3.5 fill-current text-amber-400" />
        ))}
      </div>

      {/* Quote */}
      <div className="relative mb-5">
        <Quote className="w-5 h-5 absolute -top-1 -left-1 opacity-20" style={{ color: t.color }} />
        <p className="text-white/70 text-sm leading-relaxed pl-4 italic">{t.quote}</p>
      </div>

      {/* Author */}
      <div className="flex items-center gap-3">
        <div
          className="w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0"
          style={{ background: `${t.color}20`, color: t.color, border: `1px solid ${t.color}30` }}
        >
          {t.avatar}
        </div>
        <div>
          <p className="text-white text-sm font-semibold">{t.name}</p>
          <p className="text-white/40 text-xs">{t.role} · {t.country}</p>
        </div>
      </div>
    </div>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────

export const TrustProofSection: React.FC = () => {
  const [verifying, setVerifying] = useState(true);
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const stats = usePlatformStats();

  useEffect(() => {
    const t = setTimeout(() => setVerifying(false), 1500);
    return () => clearTimeout(t);
  }, []);

  // Auto-rotate testimonials
  useEffect(() => {
    const t = setInterval(() => {
      setActiveTestimonial(i => (i + 1) % TESTIMONIALS.length);
    }, 4500);
    return () => clearInterval(t);
  }, []);

  const sampleCode = 'DCCS-AUDIO-2026-A7B3X9';

  return (
    <div className="relative py-24 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-black via-blue-950/20 to-black" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        {/* ── Live stats bar ── */}
        <div
          className="grid grid-cols-3 gap-4 sm:gap-6 max-w-2xl mx-auto mb-20 rounded-2xl p-6 sm:p-8"
          style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)' }}
        >
          {[
            { value: formatCount(stats.total_creators), label: 'Creators Protected' },
            { value: formatCount(stats.total_uploads),  label: 'Assets Registered'  },
            { value: formatCount(stats.total_codes),    label: 'DCCS Codes Issued'  },
          ].map(({ value, label }) => (
            <div key={label} className="text-center">
              <p
                className="font-bold text-white mb-1"
                style={{ fontSize: 'clamp(1.5rem, 4vw, 2.25rem)' }}
              >
                {value}
              </p>
              <p className="text-white/40 text-xs sm:text-sm">{label}</p>
            </div>
          ))}
        </div>

        {/* ── Two-column: proof + testimonials ── */}
        <div className="grid lg:grid-cols-2 gap-16 items-start">

          {/* Left — features + verification demo */}
          <div>
            <div className="inline-flex items-center gap-2 bg-blue-500/10 border border-blue-500/30 rounded-full px-4 py-2 mb-6">
              <Shield className="w-4 h-4 text-blue-400" />
              <span className="text-sm font-semibold text-blue-400">VERIFIED SYSTEM</span>
            </div>

            <h2 className="text-4xl sm:text-5xl font-bold text-white mb-6 leading-tight">
              Every Asset.
              <br />
              <span className="bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
                Permanently Verified.
              </span>
            </h2>

            <p className="text-gray-400 mb-8 leading-relaxed">
              DCCS provides cryptographic proof of ownership that anyone can verify, anywhere in the world, at any time.
            </p>

            <div className="space-y-4 mb-10">
              {[
                { icon: CheckCircle, color: '#22c55e', title: 'Instant Verification',  body: 'Anyone can verify ownership in seconds using your DCCS code' },
                { icon: Globe,       color: '#0ea5e9', title: 'Global Registry',        body: 'Recognized worldwide as proof of original creation' },
                { icon: Lock,        color: '#f59e0b', title: 'Immutable Proof',        body: 'Timestamp and ownership locked in permanent ledger' },
              ].map(({ icon: Icon, color, title, body }) => (
                <div key={title} className="flex items-start gap-4">
                  <div
                    className="flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center"
                    style={{ background: `${color}12`, border: `1px solid ${color}25` }}
                  >
                    <Icon className="w-5 h-5" style={{ color }} />
                  </div>
                  <div>
                    <h3 className="text-white font-semibold mb-1">{title}</h3>
                    <p className="text-gray-400 text-sm">{body}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Verification demo card */}
            <div
              className="relative rounded-3xl p-8 overflow-hidden"
              style={{ background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(20px)', border: '1px solid rgba(255,255,255,0.1)' }}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-cyan-500/5 pointer-events-none" />
              <div className="relative space-y-6">
                <div>
                  <label className="text-gray-400 text-xs font-semibold uppercase tracking-wider mb-3 block">
                    Sample DCCS Clearance Code
                  </label>
                  <DCCSCodeDisplay code={sampleCode} size="lg" showExplanation={true} />
                </div>

                <div className="border-t border-white/10 pt-6">
                  {verifying ? (
                    <div className="flex items-center gap-4 p-5 rounded-xl" style={{ background: 'rgba(14,165,233,0.08)', border: '1px solid rgba(14,165,233,0.2)' }}>
                      <div className="w-7 h-7 border-2 border-sky-500 border-t-transparent rounded-full animate-spin flex-shrink-0" />
                      <div>
                        <p className="text-white font-semibold text-sm">Verifying ownership...</p>
                        <p className="text-sky-300/70 text-xs">Checking global registry</p>
                      </div>
                    </div>
                  ) : (
                    <div
                      className="relative rounded-xl p-6 overflow-hidden"
                      style={{ background: 'rgba(34,197,94,0.08)', border: '1px solid rgba(34,197,94,0.25)' }}
                    >
                      <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 bg-green-500/15 p-3 rounded-xl border border-green-500/30">
                          <CheckCircle className="w-8 h-8 text-green-400" />
                        </div>
                        <div>
                          <h3 className="text-2xl font-bold text-white mb-1">VERIFIED</h3>
                          <p className="text-green-300/80 text-sm mb-3">Ownership confirmed in DCCS global registry</p>
                          <div className="space-y-1.5 text-sm">
                            <p className="text-gray-400">Creator: <span className="text-white font-semibold">John Smith</span></p>
                            <p className="text-gray-400">Registered: <span className="text-white font-semibold">January 15, 2026</span></p>
                            <p className="text-gray-400">Type: <span className="text-white font-semibold">Audio Recording</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                <p className="text-gray-500 text-xs text-center">
                  This verification is publicly accessible and can be checked by anyone, anywhere.
                </p>
              </div>
            </div>
          </div>

          {/* Right — testimonials */}
          <div>
            <div className="mb-8">
              <p className="text-white/30 text-xs uppercase tracking-widest mb-2">From creators worldwide</p>
              <h3 className="text-2xl font-bold text-white">What creators say</h3>
            </div>

            <div className="space-y-4">
              {TESTIMONIALS.map((t, i) => (
                <button
                  key={t.name}
                  onClick={() => setActiveTestimonial(i)}
                  className="w-full text-left"
                >
                  <TestimonialCard t={t} active={i === activeTestimonial} />
                </button>
              ))}
            </div>

            {/* Dot indicator */}
            <div className="flex items-center gap-2 mt-6 justify-center">
              {TESTIMONIALS.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setActiveTestimonial(i)}
                  className="rounded-full transition-all duration-300"
                  style={{
                    width:      i === activeTestimonial ? '20px' : '6px',
                    height:     '6px',
                    background: i === activeTestimonial ? '#0ea5e9' : 'rgba(255,255,255,0.2)',
                  }}
                />
              ))}
            </div>

            {/* Trust badges */}
            <div
              className="mt-10 rounded-xl px-5 py-5 grid grid-cols-2 gap-4"
              style={{ background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(255,255,255,0.07)' }}
            >
              {[
                { label: '100% Free',       sub: 'No hidden fees, forever' },
                { label: 'Worldwide',        sub: '15+ languages supported' },
                { label: 'Instant',          sub: 'Code in under 3 seconds' },
                { label: 'Permanent',        sub: 'Records never deleted' },
              ].map(({ label, sub }) => (
                <div key={label} className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-white text-sm font-semibold">{label}</p>
                    <p className="text-white/35 text-xs">{sub}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
